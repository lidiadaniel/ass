from django.contrib import admin
from product.models import *
# Register your models here.


admin.site.register(ComapanyInformation)
admin.site.register(Product)
admin.site.register(Category)
admin.site.register(aboutUS)
#admin.site.register(MyForm)
